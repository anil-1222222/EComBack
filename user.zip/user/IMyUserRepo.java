package com.nt.user;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


public interface IMyUserRepo extends JpaRepository<MyUser, Integer> {

	Optional<MyUser> findByUsername(String username);
}
