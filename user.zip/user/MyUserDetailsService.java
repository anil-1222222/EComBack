package com.nt.user;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class MyUserDetailsService implements UserDetailsService {
	
	@Autowired
	private IMyUserRepo repo;
	
	public static String CURRENT_USER="";

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<MyUser> user = repo.findByUsername(username);
		CURRENT_USER=username;
		System.out.println("CURRENT USER: "+CURRENT_USER);
		if(user.isPresent()) {
			MyUser myUser = user.get();
			return User.builder()
			.username(myUser.getUsername())
			.password(myUser.getPassword())
			.roles(getRoles(myUser))
			.build();
			
		}
		else {
			throw new UsernameNotFoundException(username);
		}
	}

	private String[] getRoles(MyUser myUser) {
		if(myUser==null) {
			return new String[]{"USER"};
		}
		return myUser.getRoles().split(",");
	}



}
