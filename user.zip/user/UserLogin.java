package com.nt.user;

public record UserLogin(String username,String password) {

}
