package com.nt.product;

public class ProductDescription {

}
