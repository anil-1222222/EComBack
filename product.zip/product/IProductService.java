package com.nt.product;

import java.util.List;

import org.springframework.data.domain.Page;

public interface IProductService {
	
	public void addProduct(Product prod);
	
	public List<Product> getAllProducts(int pageNumber,String searchKey);
	
	public void deleteById(Integer id);
	
	public Product getProductById(Integer id);
	
	public List<Product> getProductDetails(boolean isSingleProductCheckout,Integer prodId,String user);

}
