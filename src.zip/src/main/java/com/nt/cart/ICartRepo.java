package com.nt.cart;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ICartRepo extends JpaRepository<Cart, Integer> {
	
	List<Cart> findByUser(String user);

}
