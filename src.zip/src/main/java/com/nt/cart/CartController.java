package com.nt.cart;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("cart")
public class CartController {
	@Autowired
	private ICartService cartService;
	
	@GetMapping("getToCart/{prodId}/{username}")
	public Cart addToCart(@PathVariable("prodId")Integer prodId,@PathVariable("username")String username) {
		return cartService.addToCart(prodId,username);
	
	}
	
	@GetMapping("cartDetails/{username}")
	public List<Cart> getCartByUser(@PathVariable("username")String username){
		System.out.println("cartUser :"+username);
		List<Cart> cart = cartService.getByUser(username);
		return cart;
	}
	
	@DeleteMapping("delete/{prodId}")
	public void deleteToCart(@PathVariable("prodId")Integer prodId) {
		System.out.println("delete"+prodId);
		cartService.deleteCartIten(prodId);
	return;
	}
	
	@DeleteMapping("deleteAll")
	public void deleteAll() {
		cartService.deleteAll();;
	return;
	}

}
