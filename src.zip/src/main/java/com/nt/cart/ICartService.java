package com.nt.cart;

import java.util.List;

public interface ICartService {
	
	public Cart addToCart(Integer prodId,String username);
	List<Cart> getByUser(String user);
	
	public void deleteCartIten(Integer id);
	
	public void deleteAll();

}
