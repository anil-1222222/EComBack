package com.nt.order;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.cart.Cart;
import com.nt.cart.ICartRepo;
import com.nt.product.IProductRepo;
import com.nt.product.Product;
import com.nt.product.ProductController;
import com.nt.user.IMyUserRepo;
import com.nt.user.MainController;
import com.nt.user.MyUser;
import com.nt.user.MyUserDetailsService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@Service
public class OrderDetailsServiceImpl implements IOrderDetailsService{
	@Autowired
	private IOrderDetailsRepo orderRepo;
	@Autowired
	private IProductRepo prodRepo;
	@Autowired
	private IMyUserRepo userRepo;
	@Autowired
	private ICartRepo cartRepo;
	
	private static final String ORDER_PLACED="Placed";
	
	private static final String KEY="rzp_test_m9RpPBZr2gCWni";
	private static final String KEY_SECRET ="ofoHUaeYdaQQch1xT9CUejrK";
	private static final String CURRENCY="INR";
	

	@Override
	public void placeOrder(OrderInput orderInput,boolean isCartCheckout) {
		List<OrderProductQuantity> orderProductQuantityList = orderInput.getOrderProductQuantityList();
	  
		
		for(OrderProductQuantity o:orderProductQuantityList) {
			Product product = prodRepo.findById(o.getProdId()).get();
			System.out.println(product);
			 String currentUser=MyUserDetailsService.CURRENT_USER;
			 MyUser user = userRepo.findByUsername(currentUser).get();
			 System.out.println(user);
			
			OrderDetails orderDetails = new OrderDetails(
				 orderInput.getfullName(),
				 orderInput.getfullAddress(),
				 orderInput.getContactNumber(),
				 orderInput.getAlternateContactNumber(),
				 ORDER_PLACED,
				 product.getProductDiscountPrice()*o.getQuantity(),
				 product,
				 currentUser
					);
			
			System.out.println(orderDetails);
			if(!isCartCheckout) {
				List<Cart> cart = cartRepo.findByUser(currentUser);
				cart.stream().forEach(x->cartRepo.deleteById(x.getCartId()));
			}
			orderRepo.save(orderDetails);
		}
		return;
	}

	@Override
	public List<OrderDetails> getOrderDetails(String username) {
		// TODO Auto-generated method stub
		return orderRepo.findByUser(username);
	}

	@Override
	public List<OrderDetails> getAllOrders(String status) {
		if(status.equals("All")) {
			return orderRepo.findAll();
		}
		else {
			return orderRepo.findByOrderStatus(status);
		}
		
	}

	@Override
	public void markOrderAsDelivered(Integer orderId) {
		OrderDetails orderDetail = orderRepo.findById(orderId).get();
		if(orderDetail!=null) {
			orderDetail.setOrderStatus("Delivered");
			orderRepo.save(orderDetail);
		}
		
	}

	@Override
	public TransactionDetails createTransaction(BigInteger amount) {
		System.out.println("OrderDetailsServiceImpl.createTransaction()");
	    //amount
		//currency
		//key
		//secreteKey
		try {
			
			RazorpayClient razorPayClient=new RazorpayClient(KEY,KEY_SECRET);
			JSONObject options=new JSONObject();
			options.put("amount", amount.multiply(new BigInteger("100")));
			options.put("currency", "INR");
			options.put("receipt", "txn_123456");
			options.put("payment_capture", 1);
			Order order = razorPayClient.orders.create(options);
			System.out.println(order);
			return prepareTransactionDetails(order);
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("jhgc");
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	private TransactionDetails prepareTransactionDetails(Order order) {
		String orderId = order.get("id");
		String currency=order.get("currency");
		Integer amount=order.get("amount");
		
		TransactionDetails td = new TransactionDetails();
		td.setOrderId(orderId);
		td.setCurrency(currency);
		td.setAmount(amount);
		td.setKey(KEY);
		return td;
	}

}
