package com.nt.order;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("order")
public class OrderDetailsController {
	@Autowired
	private IOrderDetailsService orderService;

	@PostMapping("placeOrder/{isCartCheckout}")
	public void placeOrder(@PathVariable("isCartCheckout")boolean isCartCheckout ,@RequestBody OrderInput orderInput) {
		System.out.println("Heloo");
		System.out.println(orderInput);
		orderService.placeOrder(orderInput,isCartCheckout);
		return;
	}
	
	@GetMapping("getOrderDetails/{username}")
	public List<OrderDetails> getOrderDetails(@PathVariable("username")String username){
		return orderService.getOrderDetails(username);
	}
	
	@GetMapping("getOrders/{status}")
	public List<OrderDetails> getOrders(@PathVariable("status")String status){
		return orderService.getAllOrders(status);
	}
	
	@GetMapping("markOrderAsDelivered/{orderId}")
	public void markOrderAsDelivered(@PathVariable("orderId")Integer orderId) {
		orderService.markOrderAsDelivered(orderId);
		return;
	}
	
	@GetMapping("/createTransaction/{amount}")
	public TransactionDetails createTransaction(@PathVariable("amount")BigInteger amount) {
		TransactionDetails transaction = orderService.createTransaction(amount);
		return transaction;
	}
}
