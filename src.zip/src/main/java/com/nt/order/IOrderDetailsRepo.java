package com.nt.order;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IOrderDetailsRepo extends JpaRepository<OrderDetails, Integer> {
	
	public List<OrderDetails> findByUser(String user);
	public List<OrderDetails> findByOrderStatus(String status);

}
