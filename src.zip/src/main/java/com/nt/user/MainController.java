package com.nt.user;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.jsonwebtoken.Jwts;
import jakarta.xml.bind.DatatypeConverter;




@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("user")
public class MainController {
	
	@Autowired
	private AuthenticationManager authManager;
	
	@Autowired
	private IMyUserRepo repo;
	
	@Autowired
	private PasswordEncoder pass;
	
	@Autowired
	private JwtService jwtService;
	
	@Autowired
	private MyUserDetailsService myUserDetailsService;
	
	
	@PostMapping("/token")
	@CrossOrigin("http://localhost:4200")
	public ResponseToken validateAndGenerateToken(@RequestBody UserLogin userlogin) {
		ResponseToken rt = new ResponseToken();
		System.out.println("MainController.validateAndGenerateToken()");
		System.out.println(userlogin);
		UsernamePasswordAuthenticationToken upat = new UsernamePasswordAuthenticationToken(userlogin.username(), userlogin.password());
		Authentication authenticate = authManager.authenticate(upat);
		if(authenticate.isAuthenticated()) {
			System.out.println(jwtService.generateToken(myUserDetailsService.loadUserByUsername(userlogin.username())));
		   	String token = jwtService.generateToken(myUserDetailsService.loadUserByUsername(userlogin.username()));
		   	rt.setUsername(userlogin.username());
		   	rt.setPassword(userlogin.password());
		   	rt.setToken(token);
		   	MyUser myUser = repo.findByUsername(userlogin.username()).get();
				if(myUser==null) {
					 rt.setRole(new String[]{"USER"});
				}
				else {
					rt.setRole(myUser.getRoles().split(","));
			}
		   	return rt;
		}
		throw new UsernameNotFoundException("Invalid Credintials");

	}

	@PostMapping("/register")
	public MyUser register(@RequestBody MyUser user) {
		System.out.println("LoginController.register()");
		user.setPassword(pass.encode(user.getPassword()));
		return repo.save(user);
	}
	
	@GetMapping("/key")
	public String generateToken() {
		SecretKey key = Jwts.SIG.HS512.key().build();
		String encodedKey = DatatypeConverter.printHexBinary(key.getEncoded());
		return encodedKey;
	}
	
	@GetMapping("/home")
	public String home() {
		return "WELCOME TO HOME PAGE";
	}
	@GetMapping("/admin")
	public String admin() {
		return "WELCOME TO ADMIN PAGE";
	}
	@GetMapping("/user")
	public String user() {
		return "WELCOME TO USER PAGE";
	}
	
	
}
