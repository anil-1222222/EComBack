package com.nt.product;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.EntityManager;

@RestController
@RequestMapping("product")
@CrossOrigin("http://localhost:4200")
public class ProductController {
	@Autowired
	private IProductService service;
	
	
	@PostMapping("addNewProduct")
	public void addProduct(@RequestPart("prod") Product prod,@RequestPart("imageFile")MultipartFile[] files) throws IOException{
		
		Product p = new Product();
		if(prod.getProdId()>0) {
		    p.setProdId(prod.getProdId());
		}
		p.setProductName(prod.getProductName());
		p.setProductDescription(prod.getProductDescription());
		p.setProductDiscountPrice(prod.getProductDiscountPrice());
		p.setProductActualPrice(prod.getProductActualPrice());
		p.setProductImages(uploadImage(files));
		service.addProduct(p);
		System.out.println(p);
		return;      
	       
	}
	
	public Set<ImageModel> uploadImage(MultipartFile[] files) throws IOException{
		Set<ImageModel> imageModels = new HashSet<>();
		
		for(MultipartFile file:files) {
	    	   ImageModel im = new ImageModel();
		       im.setName(file.getOriginalFilename());
		       im.setType(file.getContentType());
		       im.setPicByte(file.getBytes());
		      // service.addImageModels(im);
		       imageModels.add(im);
	       }
		return imageModels;
	}

	@GetMapping("products")
	public List<Product> getAllProducts(@RequestParam(defaultValue = "0")int pageNumber,@RequestParam(defaultValue = "")String searchKey){
		System.out.println(pageNumber);
		List<Product> allProducts =  service.getAllProducts(pageNumber,searchKey);
		//List<Product> sorted = allProducts.stream().sorted((a,b)->(b.getProductName().compareToIgnoreCase(a.getProductName()))).limit(5).collect(Collectors.toList());
		//List<Product> sorted = allProducts.stream().sorted((a,b)->(b.getProductName().compareToIgnoreCase(a.getProductName()))).skip(2).collect(Collectors.toList());

		return allProducts;
	}
	
	@DeleteMapping("delete/{prodId}")
	public void deleteProduct(@PathVariable("prodId") Integer prodId) {
		service.deleteById(prodId);
		return ;
		
	}
	
	@GetMapping("getProductById/{prodId}")
	public Product getProductById(@PathVariable("prodId") Integer prodId) {
		Product productById = service.getProductById(prodId);
		System.out.println(productById);
		return productById;
	}
	
	@GetMapping("getProductDetails/{isSingleProductCheckout}/{prodId}/{username}")
	public List<Product> getProductDetails(@PathVariable("isSingleProductCheckout") boolean isSingleProductCheckout,@PathVariable("prodId")Integer prodId,@PathVariable("username")String username) {
		return service.getProductDetails(isSingleProductCheckout, prodId,username);
	}
	
	
}
