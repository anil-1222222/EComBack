package com.nt.product;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.nt.cart.Cart;
import com.nt.cart.ICartRepo;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductRepo repo;
	@Autowired
	private ICartRepo cartRepo;
	@Override
	public void addProduct(Product prod) {
		System.out.println("ProductServiceImpl.addProduct()");
		System.out.println(prod);
		repo.save(prod);
		return ;
		
	}
	
	@Override
	public List<Product> getAllProducts(int pageNumber,String searchKey) {
		Pageable pageable=PageRequest.of(pageNumber, 8);
		if(searchKey.equals("")) {
			return repo.findAll(pageable).toList();
		}else {
			return repo.findByProductNameContainingIgnoreCaseOrProductDescriptionContainingIgnoreCase(searchKey, searchKey, pageable).toList();
		}
		
	}
	
	@Override
	public void deleteById(Integer id) {
		repo.deleteById(id);
		return ;
		
	}
	@Override
	public Product getProductById(Integer id) {
		return repo.findById(id).get();
	}
	@Override
	public List<Product> getProductDetails(boolean isSingleProductCheckout, Integer prodId,String user) {
		if(isSingleProductCheckout && prodId!=0) {
			//we are going to buy a single product
			List<Product> list=new ArrayList<>();
			Product product = repo.findById(prodId).get();
			list.add(product);
			return list;
		}
		else {
			//we are going to checkout entire cart
			List<Cart> cart = cartRepo.findByUser(user);
			cartRepo.deleteAll(cart);
		return cart.stream().map(x->x.getProduct()).collect(Collectors.toList());
		}
		
		
		
	}

}
