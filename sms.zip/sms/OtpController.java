package com.nt.sms;

import java.util.concurrent.CompletableFuture;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.rest.api.v2010.account.MessageCreator;
import com.twilio.type.PhoneNumber;

@RestController
@RequestMapping("otp")
public class OtpController {

	public String home() {
		return "home page";
	}
	 public static final String ACCOUNT_SID = "AC8603d67d62bd5febb12c997e01bbbe3a";
	  public static final String AUTH_TOKEN = "a9b1daf68c38516284cee9c0fdeb45b6";
	
	
	@GetMapping("/sent-otp")
	public void sentSMS() {
		 Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
		 Message message = Message.creator(
			      new com.twilio.type.PhoneNumber("+916363069552"),
			      new com.twilio.type.PhoneNumber("+19594568842"),
			      "5678")
			    .create();

		    System.out.println(message);
	}
}
