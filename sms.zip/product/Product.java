package com.nt.product;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;


@Entity
@Table(name = "PROD")
public class Product {
	
	@Id
	@GeneratedValue
	private Integer prodId;
	private String productName;
	@Column(length = 500000)
	private String productDescription;
	private Double productDiscountPrice;
	private Double productActualPrice;
	
	@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinTable(
	  name = "prod_img", 
	  joinColumns = @JoinColumn(name = "prod_id"), 
	  inverseJoinColumns = @JoinColumn(name = "img_id"))
	private Set<ImageModel> productImages;
	
	
	
	public Set<ImageModel> getProductImages() {
		return productImages;
	}
	public void setProductImages(Set<ImageModel> productImages) {
		this.productImages = productImages;
	}
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public Double getProductDiscountPrice() {
		return productDiscountPrice;
	}
	public void setProductDiscountPrice(Double productDiscountPrice) {
		this.productDiscountPrice = productDiscountPrice;
	}
	public Double getProductActualPrice() {
		return productActualPrice;
	}
	public void setProductActualPrice(Double productActualPrice) {
		this.productActualPrice = productActualPrice;
	}
	
	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", productName=" + productName + ", productDescription="
				+ productDescription + ", productDiscountPrice=" + productDiscountPrice + ", productActualPrice="
				+ productActualPrice + ", productImages=" + productImages + "]";
	}
	
	

}
