package com.nt.cart;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.product.IProductRepo;
import com.nt.product.Product;
import com.nt.user.IMyUserRepo;
import com.nt.user.JwtAuthenticationFilter;
import com.nt.user.MyUser;
import com.nt.user.MyUserDetailsService;

@Service
public class CartServiceImpl implements ICartService {

	@Autowired
	private ICartRepo cartRepo;
	@Autowired
	private IProductRepo prodRepo;
	@Autowired
	private IMyUserRepo userRepo;
	String currentUser=JwtAuthenticationFilter.CURRENT_USER;
	@Override
	public Cart addToCart(Integer prodId,String username) {
		 
		Product product = prodRepo.findById(prodId).get();
		Cart cart = new Cart();
		if(product!=null) {
			cart.setProduct(product);
			cart.setUser(username);
		}
		return cartRepo.save(cart);
	}

	@Override
	public List<Cart> getByUser(String user) {
		
		return cartRepo.findByUser(user);
	}

	@Override
	public void deleteCartIten(Integer id) {
		cartRepo.deleteById(id);
		return;
		
	}

	@Override
	public void deleteAll() {
		cartRepo.deleteAll();
		return ;
		
	}

}
