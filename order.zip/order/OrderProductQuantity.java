package com.nt.order;

public class OrderProductQuantity {
	
	private Integer prodId;
	private Integer quantity;
	
	
	
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "OrderProductQuantity [prodId=" + prodId + ", quantity=" + quantity + "]";
	}
	
	

}
