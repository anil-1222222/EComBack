package com.nt.order;

import java.math.BigInteger;
import java.util.List;

public interface IOrderDetailsService {

	public void placeOrder(OrderInput orderInput,boolean isCartCheckout);
	
	public List<OrderDetails> getOrderDetails(String username);
	
     public List<OrderDetails> getAllOrders(String status);
     public void markOrderAsDelivered(Integer orderId);
     
     public TransactionDetails createTransaction(BigInteger amount);
}
